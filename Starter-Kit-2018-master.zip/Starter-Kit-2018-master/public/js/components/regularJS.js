webpackJsonp([0],{

/***/ 99:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


console.log('Welcome To The Rocky Stack');

/***/ })

},[99]);